export default()=>{

    return <div>
        <h1>
           yeh dashboard h
        </h1>
    </div>

}