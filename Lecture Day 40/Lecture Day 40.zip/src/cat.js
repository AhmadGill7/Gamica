export function sayHi(){
    alert('mioon')
}

export let name = 'Noman';