export default function makeBiryani(){
    console.log('biryani is baning');
}

export let name  = 'ali';

export function makePakorey(){
    console.log('Pakorey are taling');
}