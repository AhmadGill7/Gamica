export let data = [{name:'haleem', price:250}, {name:'biryani', price:350}, {name:'nihari', price:150}, {name:'pizza', price:850}];
