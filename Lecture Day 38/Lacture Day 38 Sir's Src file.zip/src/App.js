import { Header } from "./components/header/header";
import { Footer } from "./components/footer/footer";
import './App.css';
import { Card } from "./components/card/card";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/home/home";
import { useState } from "react";

// import { data } from "./myData";

function Login(){
  return <div>
    <h1>yeh login tha</h1>
  </div>
}

function Signup(){
  return <div>
    <h1>yeh signup tha</h1>
  </div>
}

function NotFound(){
  return <div>
    <h1>Sorry, page not found</h1>
  </div>
}

// App.js file aapke project ki main file hoti h
// project kay saarey components ultimately yahin aakar jamah hote
// aur browser m enter hojate

// yeh libraries apne main folder wali CMD m install karlijega
// npm install react-router-dom react-redux redux react-hook-form


// App.js m bi aik component hota jo saare components kay tag apne andr lgakar
// khud browser m chla jata

// react wlay code m HTML tag ko just ID se access nahi kar skate
// document.getElementById() use krna parna

function Test(){

  function sum(){

    document.getElementById('three').value = +document.getElementById('one').value + +document.getElementById('two').value;

  }

  return <div>
    <input id="one" />
    <input id="two" />
    <input id="three" />
    <button onClick={sum}>Sum</button>
  </div>

}

// map ka function
// props (component kay andr data pass krna)
// hooks (choti choti functionalities)
// state management

// npm install react-router-dom

export default function BaraComponent(){


  // data.forEach((name)=>{

  //   let e = document.createElement('li');
  //   e.innerText = name;
  //   parent1.appendChild(e);

  // })

  // MV-VM
  // MODEL VIEW - VIEW MODEL
  // data  HTML - HTML data

  let [data, setData] = useState( ['apple', 'banana', 'carrot'] );

  let [products, setProducts] = useState([]);

  const addName = ()=>{

    let newName =  prompt("Enter new anme");
    data.push(newName);
    setData([...data]);

  }

  return <div id="app">
    <BrowserRouter>

  <button onClick={addName}>Add Name</button>
    <ol>
      {
        data.map(function(dish, meraIndex){
          return <li>
              {dish}
              <button onClick={()=>{

                data.splice(meraIndex, 1);
                setData([...data]); 

              }}>Delete</button>
            </li>
        })
      }
    </ol>

    <Header ></Header>

    <main>

{/* routes ki 2 types */}
{/* static routes and dynamic routes */}
    {/* <Routes>
       <Route path="/" element={<Home></Home>} />       
       <Route path="/login" element={<Login></Login>} />
       <Route path="/:hello" element={<Login></Login>} />
       <Route path="/signup" element={<Signup></Signup>} />
       <Route path="*" element={<NotFound></NotFound>} />
    </Routes>

    <Test></Test> */}

  
    </main>
    <Footer></Footer>

    </BrowserRouter>
  </div>

}