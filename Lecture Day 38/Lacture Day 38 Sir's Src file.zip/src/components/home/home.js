import { Card } from "../card/card"

export default()=>{

    return   <div className="flex">
    <Card></Card>
    <Card></Card>
    <Card></Card>
  </div>


}